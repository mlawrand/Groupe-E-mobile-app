// ignore_for_file: unused_import

import 'dart:io'; // Add this import
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart'; // Ensure this is imported
import 'package:aunthentication_app/models/user_model.dart';

class ProfileScreen extends StatefulWidget {
  final User user;

  ProfileScreen({required this.user});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late User _currentUser;
  final ImagePicker _picker = ImagePicker();
  File? _pickedImage; // Stores the selected image file

  @override
  void initState() {
    super.initState();
    _currentUser = widget.user;
  }

  Future<void> _pickImage() async {
    final File? pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
    );

    if (pickedFile != null) {
      setState(() {
        _pickedImage = File(pickedFile.path); // Convert XFile to File
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundImage: _pickedImage != null
                    ? FileImage(_pickedImage!) // Use the picked file
                    : (_currentUser.profileImageUrl != null
                        ? NetworkImage(_currentUser.profileImageUrl!)
                        : null) as ImageProvider<Object>?,
                child: _pickedImage == null && _currentUser.profileImageUrl == null
                    ? Icon(Icons.camera_alt, size: 40)
                    : null,
              ),
            ),
            SizedBox(height: 20),
            Text('Name: ${_currentUser.name}'),
            Text('Email: ${_currentUser.email}'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Save the image path to user model if needed
                if (_pickedImage != null) {
                  setState(() {
                    _currentUser = _currentUser.copyWith(
                      profileImageUrl: _pickedImage!.path,
                    );
                  });
                }
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Profile updated!')),
                );
              },
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}

class ImagePicker {
  pickImage({required source}) {}
}

class ImageSource {
  // ignore: prefer_typing_uninitialized_variables
  static var gallery;
}