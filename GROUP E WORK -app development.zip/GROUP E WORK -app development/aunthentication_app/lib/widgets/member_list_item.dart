import 'package:flutter/material.dart';
import 'package:aunthentication_app/models/user_model.dart';

class MemberListItem extends StatelessWidget {
  final User user;

  const MemberListItem({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      margin: EdgeInsets.symmetric(horizontal: 8),
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox( // Constrains height
            height: 140, // Fixed height to prevent overflow
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min, // Prevents column expansion
              children: [
                ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: 60),
                  child: CircleAvatar(
                    radius: 24,
                    child: Text(user.name.isNotEmpty ? user.name[0] : '?'),
                  ),
                ),
                SizedBox(height: 8),
                Flexible( // Allows text to shrink if needed
                  child: Text(
                    user.name,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
                Flexible(
                  child: Text(
                    user.email,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}